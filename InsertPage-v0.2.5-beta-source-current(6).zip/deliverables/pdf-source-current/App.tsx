import React, {useState} from 'react';
import {NativeModules, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {PluginCommAPI, PluginFileAPI, PluginManager, RattaFileSelector} from 'sn-plugin-lib';

const {InsertPageNative} = NativeModules;
type Status = 'idle' | 'working' | 'done' | 'error';
type PageBackground = 'blank' | 'lined' | 'dotted' | 'squared';
const BACKGROUNDS: Array<{id: PageBackground; label: string; sample: string}> = [
  {id: 'blank', label: 'Blank', sample: '   '},
  {id: 'lined', label: 'Lined', sample: '───'},
  {id: 'dotted', label: 'Dotted', sample: '· · ·'},
  {id: 'squared', label: 'Squared', sample: '▦ ▦'},
];

export default function App() {
  const [status, setStatus] = useState<Status>('idle');
  const [message, setMessage] = useState('Choose a background, then insert the new page.');
  const [background, setBackground] = useState<PageBackground>('dotted');
  const busy = status === 'working';

  const getContext = async (): Promise<{filePath: string; pageIndex: number}> => {
    const pathRes: any = await PluginCommAPI.getCurrentFilePath();
    const filePath: string = pathRes?.success ? pathRes.result : '';
    if (!filePath || !filePath.toLowerCase().endsWith('.pdf')) throw new Error('Open a PDF before using Insert Page.');
    const pageRes: any = await PluginCommAPI.getCurrentPageNum();
    return {filePath, pageIndex: pageRes?.success && typeof pageRes.result === 'number' ? pageRes.result : 0};
  };

  const runPdfAction = async (progress: string, action: (filePath: string, pageIndex: number) => Promise<any>, success: (pageIndex: number, result: any) => string, reopenPage: (pageIndex: number) => number) => {
    if (busy) return;
    setStatus('working');
    setMessage(progress + ' Please wait—do not tap again.');
    try {
      const {filePath, pageIndex} = await getContext();
      const result = await action(filePath, pageIndex);
      setMessage('Refreshing the PDF…');
      await PluginFileAPI.openFile(filePath, reopenPage(pageIndex));
      setStatus('done');
      setMessage(success(pageIndex, result));
    } catch (err: any) {
      setStatus('error');
      setMessage('Error: ' + (err?.message ?? 'Something went wrong.'));
    }
  };

  const insertPdfHere = async () => {
    if (busy) return;
    setStatus('working');
    setMessage('Choose a PDF to insert…');
    try {
      const {filePath, pageIndex} = await getContext();
      const selected: any = await RattaFileSelector.selectFile({selectType: 1, suffixList: ['pdf'], maxNum: 1, title: 'Select PDF to insert'});
      if (!selected || selected.length === 0) { setStatus('idle'); setMessage('No PDF selected.'); return; }
      setMessage('Inserting PDF pages… Please wait—do not tap again.');
      const count = await InsertPageNative.insertPdfAfter(filePath, pageIndex, selected[0]);
      setMessage('Refreshing the PDF…');
      await PluginFileAPI.openFile(filePath, pageIndex + 1);
      setStatus('done');
      setMessage(`${count} PDF page${count === 1 ? '' : 's'} inserted.`);
    } catch (err: any) {
      setStatus('error');
      setMessage('Error: ' + (err?.message ?? 'Something went wrong.'));
    }
  };

  return <View style={styles.screen}><View style={styles.panel}>
    <View style={styles.header}><Text style={styles.title}>INSERT PAGE</Text><Text style={styles.version}>BETA 0.2.5</Text></View>
    <Text style={styles.message}>{message}</Text><Text style={styles.sectionLabel}>New page background</Text>
    <View style={styles.backgroundRow}>{BACKGROUNDS.map(item => <TouchableOpacity key={item.id} style={[styles.backgroundChoice, item.id === background && styles.backgroundSelected]} onPress={() => setBackground(item.id)} disabled={busy}><Text style={styles.sample}>{item.sample}</Text><Text style={styles.choiceText}>{item.label}</Text></TouchableOpacity>)}</View>
    <TouchableOpacity style={styles.button} onPress={() => runPdfAction(`Inserting a ${background} page…`, (filePath, pageIndex) => InsertPageNative.insertPageAfter(filePath, pageIndex, background), pageIndex => `${background.charAt(0).toUpperCase() + background.slice(1)} page inserted after page ${pageIndex + 1}.`, pageIndex => pageIndex + 1)} disabled={busy}><Text style={styles.buttonText}>Insert {background} page here</Text></TouchableOpacity>
    <TouchableOpacity style={[styles.button, styles.pdf]} onPress={insertPdfHere} disabled={busy}><Text style={styles.buttonText}>Insert PDF document here</Text></TouchableOpacity>
    <TouchableOpacity style={[styles.button, styles.delete]} onPress={() => runPdfAction('Deleting the current page…', (filePath, pageIndex) => InsertPageNative.deletePageAt(filePath, pageIndex), pageIndex => `Page ${pageIndex + 1} deleted.`, pageIndex => Math.max(0, pageIndex - 1))} disabled={busy}><Text style={styles.buttonText}>Delete this page</Text></TouchableOpacity>
    <TouchableOpacity style={[styles.button, styles.undo]} onPress={() => runPdfAction('Restoring the previous PDF…', filePath => InsertPageNative.undoLastAction(filePath), () => 'Last Insert Page action undone.', pageIndex => pageIndex)} disabled={busy}><Text style={styles.buttonText}>Undo last action</Text></TouchableOpacity>
    <TouchableOpacity style={[styles.button, styles.close, busy && styles.disabled]} onPress={() => PluginManager.closePluginView().catch(() => {})} disabled={busy}><Text style={styles.buttonText}>Close</Text></TouchableOpacity>
  </View></View>;
}

const styles = StyleSheet.create({
  screen: {flex: 1, backgroundColor: '#fff', padding: 10, justifyContent: 'center'}, panel: {backgroundColor: '#fff', borderWidth: 3, borderColor: '#000', padding: 16},
  header: {backgroundColor: '#000', paddingVertical: 10, paddingHorizontal: 12, marginBottom: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between'}, title: {fontSize: 22, fontWeight: '800', color: '#fff'}, version: {fontSize: 13, fontWeight: '700', color: '#fff'},
  message: {fontSize: 14, fontWeight: '600', color: '#000', backgroundColor: '#fff', marginBottom: 12}, sectionLabel: {fontSize: 14, fontWeight: '600', marginBottom: 8}, backgroundRow: {flexDirection: 'row', marginBottom: 12},
  backgroundChoice: {flex: 1, backgroundColor: '#fff', borderWidth: 2, borderColor: '#555', paddingVertical: 6, alignItems: 'center', marginRight: 5}, backgroundSelected: {borderWidth: 3, borderColor: '#000', paddingVertical: 5}, sample: {fontSize: 14, height: 17}, choiceText: {fontSize: 12, fontWeight: '600'},
  button: {backgroundColor: '#fff', borderWidth: 3, borderColor: '#000', paddingVertical: 10, alignItems: 'center', marginBottom: 8}, pdf: {borderColor: '#06c'}, delete: {borderColor: '#900'}, undo: {borderColor: '#555'}, close: {borderColor: '#067000'}, disabled: {opacity: 0.45}, buttonText: {fontSize: 16, fontWeight: '800', color: '#000'},
});
